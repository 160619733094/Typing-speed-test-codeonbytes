# Typing Speed Test
Simple website with beautiful interface to test typing speed and count errors using different sentences.
